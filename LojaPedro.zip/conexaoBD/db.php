<?php
//conexão com o banco de dados
$conn = mysqli_connect("localhost", "root", "", "lojapedro");

//verifica se a conexão foi bem sucedida
if (!$conn) {
	die("Erro de conexão: " . mysqli_connect_error());
}