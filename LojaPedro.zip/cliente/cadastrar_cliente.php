<!DOCTYPE html>
<html>
<head>
	<title>Listagem de Clientes</title>
	<!-- Importação dos arquivos CSS do Bootstrap -->
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container py-3">
  


<?php
 include("../conexaoBD/db.php");

//recupera os dados do formulário
$nome = $_POST['nome'];
$CPF = $_POST['CPF'];
$email = $_POST['email'];
$nascimento = $_POST['nascimento'];
$idcidade = $_POST['idcidade'];
$endereco = $_POST['endereco'];
$data_cadastro = date('Y-m-d');

//insere os dados na tabela cliente
$sql = "INSERT INTO cliente (nome, CPF, email, nascimento, idcidade, endereco, data_cadastro)
		VALUES ('$nome', '$CPF', '$email', '$nascimento', '$idcidade', '$endereco', '$data_cadastro')";

if (mysqli_query($conn, $sql)) {
	 ?> 
	<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Mensagem do sistema</h4>
  <p>Seu cadastro foi realizado com sucesso. Clique no botão abaixo para retornar</p>
  <hr>
  
  <a href="../"><button class="btn btn-success mt-4">Voltar</button></a>
</div>
	  
  <?php
} else {
	echo "Erro ao cadastrar: ";
}