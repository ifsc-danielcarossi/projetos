<!DOCTYPE html>
<html>
<head>
	<title>Cadastro de Clientes</title>
	<!-- Importação dos arquivos CSS do Bootstrap -->
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container py-3">
  <header>
  
    <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
      <h1 class="display-4 fw-normal">Formulário de Cadastro </h1>
      <p class="fs-5 text-muted">Informe os dados abaixo para o cadastro</p>
    </div>
  </header>
  <a href="./"><button class="btn btn-success mt-4">Voltar para a tela de clientes</button></a>
<hr/>

<div class="container">

  <form action="cadastrar_cliente.php" method="post">
    <div class="form-group">
      <label for="nome">Nome:</label>
      <input type="text" class="form-control" id="nome" name="nome" required>
    </div>
    <div class="form-group">
      <label for="CPF">CPF:</label>
      <input type="text" class="form-control" id="CPF" name="CPF" required>
    </div>
    <div class="form-group">
      <label for="email">E-mail:</label>
      <input type="email" class="form-control" id="email" name="email" required>
    </div>
    <div class="form-group">
      <label for="nascimento">Data de Nascimento:</label>
      <input type="date" class="form-control" id="nascimento" name="nascimento" required>
    </div>
    <div class="form-group">
      <label for="idcidade">ID da Cidade:</label>
      <input type="text" class="form-control" id="idcidade" name="idcidade" required>
    </div>
    <div class="form-group">
      <label for="endereco">Endereço:</label>
      <input type="text" class="form-control" id="endereco" name="endereco" required>
    </div>
    <input type="hidden" name="data_cadastro" value="<?php echo date('Y-m-d'); ?>">
    <br/>
    
    <button type="submit" class="btn btn-primary mt-4">Cadastrar</button>
  </form>
</div>
