<!DOCTYPE html>
<html>
<head>
	<title>Exclusão de Clientes</title>
	<!-- Importação dos arquivos CSS do Bootstrap -->
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container py-3">

<?php

include("../conexaoBD/db.php");

// Verifica se foi passado o ID do cliente a ser excluído
if (isset($_GET['idcliente'])) {
    $idcliente = $_GET['idcliente'];

    // Query SQL para excluir o cliente com base no ID
    $sql = "DELETE FROM cliente WHERE idcliente = $idcliente";

    // Executa a query SQL
    if ($conn->query($sql) === TRUE) {
        ?> 
	<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Mensagem do sistema</h4>
  <p>Seu cadastro foi excluido com sucesso. </p>
  <hr>
  Clique no botão abaixo para retornar<br>
  <a href="./"><button class="btn btn-success mt-4">Voltar</button></a>
</div>
	  
  <?php
    } else {
        echo "Erro ao excluir registro: " . $conn->error;
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
