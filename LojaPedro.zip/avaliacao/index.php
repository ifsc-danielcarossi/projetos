

<!DOCTYPE html>
<html>
<head>
	<title>Listagem de Avaliações</title>
	<!-- Importação dos arquivos CSS do Bootstrap -->
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container py-3">
  <header>
  
    <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
      <h1 class="display-4 fw-normal">Lista de avaliações </h1>
      <p class="fs-5 text-muted">Relação de todas os vendedores cadastrados na base de dados</p>
    </div>
  </header>
        <a href="../"><button class="btn btn-success">Voltar para o painel principal</button></a>
       <!-- <a href="#"><button class="btn btn-primary">Novo Produto</button></a> -->
<hr/>

		<table class="table table-striped">
			<thead>
				<tr>
					<th>ID da avaliação</th>
					<th>ID do cliente</th>
					<th>ID do vendedor</th>
					<th>Descrição</th>		
					<th>Nota</th>
					<th>Data da avaliação</th>					
					<th>Ações</th>
				</tr>
			</thead>
			<tbody>
				<?php
				include("../conexaoBD/db.php");

				// Consulta SQL para selecionar todos os clientes da tabela
				$sql = "SELECT * from avaliacao";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
					// Loop para exibir todos os clientes
					while($row = $result->fetch_assoc()) {
						echo "<tr>";
						echo "<td>" . $row["idavaliacao"] . "</td>";
						echo "<td>" . $row["idcliente"] . "</td>";
						echo "<td>" . $row["idvendedor"] . "</td>";
						echo "<td>" . $row["descricao"] . "</td>";
						echo "<td>" . $row["nota"] . "</td>";
						echo "<td>" . $row["data_avaliacao"] . "</td>";
						echo "<td> ações</td>";					
						//echo "<td><a href='excluir_cliente.php?idcliente=$row[idcliente]'>excluir</a></td>";
						
						echo "</tr>";
					}
				} else {
					echo "Nenhum resultado encontrado.";
				}
				$conn->close();
				?>
			</tbody>
		</table>
	</div>
	<!-- Importação dos arquivos JavaScript do Bootstrap -->
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
